
import 'generated_route.dart';

class GeneratedRoute {
  final List<GeneratedSpot> spots;
  final int totalDuration;

  GeneratedRoute({
    required this.spots,
    required this.totalDuration
  });

  factory GeneratedRoute.fromJson(Map<String, dynamic> json) {
    return GeneratedRoute(
        spots: (json['spots'] as List<dynamic>)
            .map((e) => GeneratedSpot.fromJson(e))
            .toList(),
        totalDuration: json['totalDuration']
    );
  }
}
