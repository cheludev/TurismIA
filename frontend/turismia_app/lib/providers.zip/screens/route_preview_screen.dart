import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

import '../models/generated_route.dart' as service;

import '../models/generated_spot.dart' as service;
import '../services/route_service.dart';
import '../services/spot_service.dart';
import '../providers/auth_provider.dart';
import '../services/route_generator_service.dart';

class RoutePreviewScreen extends StatefulWidget {
  final LatLng from;
  final String toName;
  final int maxDuration;

  const RoutePreviewScreen({
    super.key,
    required this.from,
    required this.toName,
    required this.maxDuration,
  });

  @override
  State<RoutePreviewScreen> createState() => _RoutePreviewScreenState();
}

class _RoutePreviewScreenState extends State<RoutePreviewScreen> {
  late Future<service.GeneratedRoute> _futureRoute;
  final TextEditingController _titleController = TextEditingController();
  List<service.GeneratedSpot> _spots = [];

  @override
  void initState() {
    super.initState();
    _futureRoute = _loadGeneratedRoute();
  }

  Future<service.GeneratedRoute> _loadGeneratedRoute() async {
    final route = await RouteGeneratorService().generateRoute(
      from: widget.from,
      toName: widget.toName,
      maxDuration: widget.maxDuration,
    );
    _spots = route.spots;
    return route;
  }

  void _removeSpot(int index) {
    setState(() {
      _spots.removeAt(index);
    });
  }

  Future<void> _replaceSpot(int index) async {
    final spots = await SpotService().getAllSpotsInCity('Huelva');
    showModalBottomSheet(
      context: context,
      builder: (_) => ListView.builder(
        itemCount: spots.length,
        itemBuilder: (_, i) => ListTile(
          title: Text(spots[i].name),
          subtitle: Text('Lat: ${spots[i].latitude}, Lng: ${spots[i].longitude}'),
          onTap: () {
            setState(() => _spots[index] = service.GeneratedSpot.fromSpot(spots[i]));
            Navigator.pop(context);
          },
        ),
      ),
    );
  }

  void _saveRoute() async {
    final user = Provider.of<AuthProvider>(context, listen: false).user;
    if (user == null) return;

    await RouteService().createRoute(
      name: _titleController.text,
      description: '',
      spotIds: _spots.map((s) => s.id).toList(),
      cityId: 1,
      ownerId: user.id,
      duration: widget.maxDuration * 60,
    );

    if (context.mounted) Navigator.pop(context);
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Previsualización de Ruta')),
      body: FutureBuilder<service.GeneratedRoute>(
        future: _futureRoute,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          } else if (!snapshot.hasData) {
            return const Center(child: Text('No se pudo generar la ruta'));
          }

          final route = snapshot.data!;

          return Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                TextFormField(
                  controller: _titleController,
                  decoration: const InputDecoration(labelText: 'Título de la ruta'),
                ),
                const SizedBox(height: 12),
                Text('Duración estimada: ${route.totalDuration ~/ 60} minutos'),
                const Divider(),
                const Text('Spots incluidos:', style: TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                Expanded(
                  child: ListView.builder(
                    itemCount: _spots.length,
                    itemBuilder: (context, index) {
                      final spot = _spots[index];
                      return Card(
                        margin: const EdgeInsets.symmetric(vertical: 6),
                        child: ListTile(
                          title: Text(spot.name),
                          subtitle: Text('Lat: ${spot.latitude}, Lng: ${spot.longitude}'),
                          trailing: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              IconButton(
                                icon: const Icon(Icons.edit),
                                onPressed: () => _replaceSpot(index),
                              ),
                              IconButton(
                                icon: const Icon(Icons.delete),
                                onPressed: () => _removeSpot(index),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
                const SizedBox(height: 12),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    OutlinedButton(
                      onPressed: () => Navigator.pop(context),
                      child: const Text('Cancelar'),
                    ),
                    ElevatedButton(
                      onPressed: _saveRoute,
                      child: const Text('Guardar Ruta'),
                    ),
                  ],
                )
              ],
            ),
          );
        },
      ),
    );
  }
}
