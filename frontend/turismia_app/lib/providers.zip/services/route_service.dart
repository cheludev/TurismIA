import 'package:dio/dio.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import '../models/route_detail_model.dart';
import '../models/route_model.dart';

class RouteService {
  final Dio _dio = Dio(
    BaseOptions(
      baseUrl: 'http://192.168.1.136:8080/api',
    ),
  );

  Future<List<dynamic>> getPublicRoutes() async {
    const storage = FlutterSecureStorage();
    final token = await storage.read(key: 'jwt');

    if (token == null) {
      throw Exception('No hay token guardado. Inicia sesión de nuevo.');
    }

    final response = await _dio.get(
      '/routes/',
      options: Options(
        headers: {'Authorization': 'Bearer $token'},
      ),
    );

    final routes = response.data['body'] as List<dynamic>;
    return routes;
  }

  Future<void> createRoute({
    required String name,
    required String description,
    required List<int> spotIds,
    required int cityId,
    required int ownerId,
    required int duration,
  }) async {
    const storage = FlutterSecureStorage();
    final token = await storage.read(key: 'jwt');

    if (token == null) {
      throw Exception('No hay token guardado.');
    }

    final response = await _dio.post(
      '/routes',
      data: {
        'name': name,
        'description': description,
        'spotIds': spotIds,
        'cityId': cityId,
        'ownerId': ownerId,
        'duration': duration,
      },
      options: Options(
        headers: {'Authorization': 'Bearer $token'},
      ),
    );

    if (response.statusCode != 200 && response.statusCode != 201) {
      throw Exception('Error al crear la ruta');
    }
  }


  Future<RouteModel> getRouteById(int id) async {
    const storage = FlutterSecureStorage();
    final token = await storage.read(key: 'jwt');

    if (token == null) {
      throw Exception('No hay token guardado. Inicia sesión de nuevo.');
    }

    final response = await _dio.get(
      '/routes/$id',
      options: Options(
        headers: {'Authorization': 'Bearer $token'},
      ),
    );

    final json = response.data['body'];
    return RouteModel.fromJson(json);
  }




  Future<RouteDetailModel> getRouteDetail(int id) async {
    const storage = FlutterSecureStorage();
    final token = await storage.read(key: 'jwt');

    if (token == null) {
      throw Exception('No hay token guardado.');
    }

    final response = await _dio.get(
      '/routes/$id',
      options: Options(
        headers: {'Authorization': 'Bearer $token'},
      ),
    );

    final data = response.data['body'];
    return RouteDetailModel.fromJson(data);
  }



}
