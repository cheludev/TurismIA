import 'package:dio/dio.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import '../models/generated_route.dart';
import '../models/generated_spot.dart'; // debe contener GeneratedSpot

class RouteGeneratorService {
  final Dio _dio = Dio(
    BaseOptions(baseUrl: 'http://192.168.1.136:8080/api'),
  );

  Future<GeneratedRoute> generateRoute({
    required LatLng from,
    required String toName,
    required int maxDuration,
  }) async {
    final locResponse = await _dio.get('/spots/location/by-name', queryParameters: {
      'name': toName,
    });

    final to = locResponse.data['body'];

    if (to == null || to['latitude'] == null || to['longitude'] == null) {
      throw Exception('No se pudo obtener la ubicación del destino seleccionado.');
    }

    final toPoint = LatLng(to['latitude'], to['longitude']);

    final response = await _dio.post('/routes/new', data: {
      'from': {'latitude': from.latitude, 'longitude': from.longitude},
      'to': {'latitude': toPoint.latitude, 'longitude': toPoint.longitude},
      'maxDuration': maxDuration * 60,
    });

    final spots = response.data['body']['spots'] as List;

    return GeneratedRoute(
      spots: spots.map((s) => GeneratedSpot.fromJson(s)).toList(),
      totalDuration: response.data['body']['totalDuration'],
    );
  }
}
