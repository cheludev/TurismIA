import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:google_maps_webservice/places.dart';

class CreateRouteDialog extends StatefulWidget {
  final Function(LatLng from, String destination, int duration) onConfirm;

  const CreateRouteDialog({Key? key, required this.onConfirm}) : super(key: key);

  @override
  _CreateRouteDialogState createState() => _CreateRouteDialogState();
}

class _CreateRouteDialogState extends State<CreateRouteDialog> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _destinationController = TextEditingController();
  int _durationMinutes = 60;

  final places = GoogleMapsPlaces(apiKey: dotenv.env['GOOGLE_MAPS_API_KEY'] ?? '');
  List<Prediction> predictions = [];

  void autoCompleteSearch(String input) async {
    if (input.isEmpty) {
      setState(() {
        predictions = [];
      });
      return;
    }

    final response = await places.autocomplete(
      input,
      language: "es",
      components: [Component(Component.country, "es")],
    );
    print('Respuesta Autocomplete: ${response.status}');

    if (response.isOkay) {
      setState(() {
        predictions = response.predictions;
      });
    } else {
      setState(() {
        predictions = [];
      });
    }
  }

  Future<Position> _determinePosition() async {
    bool serviceEnabled;
    LocationPermission permission;

    serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      throw Exception('La ubicación no está habilitada.');
    }

    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        throw Exception('Permiso de ubicación denegado.');
      }
    }

    if (permission == LocationPermission.deniedForever) {
      throw Exception('Los permisos de ubicación están denegados permanentemente.');
    }

    return await Geolocator.getCurrentPosition();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Crear nueva ruta'),
      content: Form(
        key: _formKey,
        child: SizedBox(
          width: 300,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextFormField(
                controller: _destinationController,
                decoration: const InputDecoration(labelText: 'Destino'),
                validator: (value) => value == null || value.isEmpty ? 'Introduce destino' : null,
                onChanged: autoCompleteSearch,
              ),
              const SizedBox(height: 8),
              if (predictions.isNotEmpty)
                ConstrainedBox(
                  constraints: const BoxConstraints(maxHeight: 200),
                  child: ListView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: predictions.length,
                    itemBuilder: (context, index) {
                      return ListTile(
                        title: Text(predictions[index].description ?? ''),
                        onTap: () {
                          _destinationController.text = predictions[index].description ?? '';
                          setState(() {
                            predictions.clear();
                          });
                        },
                      );
                    },
                  ),
                ),
              const SizedBox(height: 16),
              Text('Duración máxima (minutos): $_durationMinutes'),
              Slider(
                value: _durationMinutes.toDouble(),
                min: 30,
                max: 300,
                divisions: 27,
                label: '$_durationMinutes min',
                onChanged: (value) {
                  setState(() {
                    _durationMinutes = value.round();
                  });
                },
              ),
            ],
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Cancelar'),
        ),
        ElevatedButton(
          onPressed: () async {
            if (_formKey.currentState!.validate()) {
              try {
                Position position = await _determinePosition();
                LatLng from = LatLng(position.latitude, position.longitude);
                widget.onConfirm(from, _destinationController.text.trim(), _durationMinutes);
                Navigator.pop(context);
              } catch (e) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text(e.toString())),
                );
              }
            }
          },
          child: const Text('Generar ruta'),
        ),
      ],
    );
  }
}
