import 'package:dio/dio.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class SpotService {
  final Dio _dio = Dio(
    BaseOptions(
      baseUrl: 'http://192.168.1.136:8080/api',
    ),
  );

  Future<Map<String, dynamic>> getSpotById(int id) async {
    const storage = FlutterSecureStorage();
    final token = await storage.read(key: 'jwt');

    if (token == null) {
      throw Exception('No hay token guardado.');
    }

    final response = await _dio.get(
      '/spots/$id',
      options: Options(
        headers: {'Authorization': 'Bearer $token'},
      ),
    );

    return response.data['body'];
  }
}
