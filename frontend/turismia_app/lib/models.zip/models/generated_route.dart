import 'package:google_maps_flutter/google_maps_flutter.dart';

class GeneratedSpot {
  final int? id;
  final String name;
  final String? address;
  final double latitude;
  final double longitude;
  final double? rating;
  final int averageTime;

  GeneratedSpot({
    required this.id,
    required this.name,
    required this.address,
    required this.latitude,
    required this.longitude,
    required this.rating,
    required this.averageTime
  });

  factory GeneratedSpot.fromJson(Map<String, dynamic> json) {
    return GeneratedSpot(
        id: json['id'],
        name: json['name'],
        address: json['address'],
        latitude: json['latitude'],
        longitude: json['longitude'],
        rating: json['rating'] != null ? (json['rating'] as num).toDouble() : null,
        averageTime: json['averageTime'] ?? 0
    );
  }

  LatLng get latLng => LatLng(latitude, longitude);
}

class GeneratedRoute {
  final List<GeneratedSpot> spots;
  final int totalDuration;

  GeneratedRoute({
    required this.spots,
    required this.totalDuration
  });

  factory GeneratedRoute.fromJson(Map<String, dynamic> json) {
    return GeneratedRoute(
        spots: (json['spots'] as List<dynamic>)
            .map((e) => GeneratedSpot.fromJson(e))
            .toList(),
        totalDuration: json['totalDuration']
    );
  }
}
